package view.inventory;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.LineBorder;

import net.miginfocom.swing.MigLayout;

import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JComboBox;

import com.toedter.calendar.JDateChooser;

public class ItemTileWarranty extends ItemPanelDecorator implements ItemPanelParticipant{

	private JPanel panWarranty;
	
	private JLabel lblWarranty;
	private JLabel lblStart;
	private JLabel lblEnd;
	private JLabel lblDeliveryDate;
	
	private JDateChooser startWarrantyDate;
	private JDateChooser endWarrantyDate;
	
	public ItemTileWarranty(ItemPanelTemplate addItemPanelReference) {
		super(addItemPanelReference);
		// TODO Auto-generated constructor stub
		
	}
	
	@Override
	public void renderPanel()
	{
		renderItemTileSoftwarePanel();
		super.renderPanel();
	}
	
	public void renderItemTileSoftwarePanel()
	{
		panWarranty	 = new JPanel();
		panWarranty.setBorder(new LineBorder(new Color(30, 144, 255), 3, true));
		panWarranty.setBackground(Color.WHITE);
		
		panWarranty.setLayout(new MigLayout("", "[46.00][38.00][100,grow][100,grow][100,grow][31.00]", "[][][17][][17][][]"));
		
		lblWarranty = new JLabel("Warranty:");
		lblWarranty.setFont(new Font("Arial", Font.BOLD, 20));
		panWarranty.add(lblWarranty, "cell 0 0,alignx left");
		
		lblDeliveryDate = new JLabel("Start:");
		lblDeliveryDate.setFont(new Font("Arial", Font.BOLD, 20));
		panWarranty.add(lblDeliveryDate, "flowx,cell 1 1");
		
		startWarrantyDate = new JDateChooser();
		startWarrantyDate.setOpaque(false);
		startWarrantyDate.setDate(new Date());
		startWarrantyDate.setBorder(null);
		startWarrantyDate.setFont(new Font("Arial", Font.BOLD, 20));
		startWarrantyDate.setDateFormatString("yyyy-MM-dd");
		startWarrantyDate.setBackground(Color.WHITE);
		startWarrantyDate.setPreferredSize(new Dimension(150, 30));
		panWarranty.add(startWarrantyDate, "cell 2 1 2 1,growx,aligny center");
		
		
		lblEnd = new JLabel("End:");
		lblEnd.setFont(new Font("Arial", Font.BOLD, 20));
		panWarranty.add(lblEnd, "cell 1 3,alignx left");
		
		endWarrantyDate = new JDateChooser();
		endWarrantyDate.setOpaque(false);
		endWarrantyDate.setDate(new Date());
		endWarrantyDate.setBorder(null);
		endWarrantyDate.setFont(new Font("Arial", Font.BOLD, 20));
		endWarrantyDate.setDateFormatString("yyyy-MM-dd");
		endWarrantyDate.setBackground(Color.WHITE);
		endWarrantyDate.setPreferredSize(new Dimension(150, 30));
		panWarranty.add(endWarrantyDate, "cell 2 3 2 1,growx,aligny center");
		
		
		addItemPanelReference.assignToQuad(panWarranty, 3);
		
	}
	
	@Override
	public Iterator retrieveInformation() {
		// TODO Auto-generated method stub
		ArrayList infoList = new ArrayList(); 
		infoList.add(startWarrantyDate.getDate());
		infoList.add(endWarrantyDate.getDate());
		return infoList.iterator();
	}
	
}

package view.inventory;

import java.util.Iterator;

public interface ItemPanelParticipant {
	public Iterator retrieveInformation();
}

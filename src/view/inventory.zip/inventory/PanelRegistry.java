package view.inventory;

import java.util.ArrayList;
import java.util.Iterator;

import model.InventoryItem;
import controller.ITAssetController;
import controller.InventoryItemController;

public class PanelRegistry implements PanelRegistration {

	private String type;
	private static PanelRegistry panelRegistry = new PanelRegistry();
	private ArrayList<ItemPanelParticipant> participantList;
	private TabInventory tabInventory;
	
	private PanelRegistry()
	{
		participantList = new ArrayList<ItemPanelParticipant>();
		type = "IT Assets";
	}
	
	public void clearParticipants()
	{
		participantList.clear();
	}
	@Override
	public void registerParticipant(ItemPanelParticipant itemPanelParticipant) {
		// TODO Auto-generated method stub
		participantList.add(itemPanelParticipant);
	}
	@Override
	public void unregisterParticipant(ItemPanelParticipant itemPanelParticipant) {
		// TODO Auto-generated method stub
		participantList.remove(itemPanelParticipant);
	}
	@Override
	public void retrieveInformationFromAll() {
		// TODO Auto-generated method stub
		ArrayList generalInfo = new ArrayList();
		ArrayList typeInfo = new ArrayList();
		ArrayList warrantyInfo = new ArrayList();
		ArrayList contractInfo = new ArrayList();
		
		for(int i = 0; i < participantList.size();i++)
		{
			switch(i)
			{
			case 1:
				Iterator iter = participantList.get(i).retrieveInformation();
				while(iter.hasNext())
				{
					generalInfo.add(iter.next());
				}
				break;
			case 2:
				Iterator iter2 = participantList.get(i).retrieveInformation();
				while(iter2.hasNext())
				{
					typeInfo.add(iter2.next());
				}
				break;
			
			case 3:
				Iterator iter3 = participantList.get(i).retrieveInformation();
				while(iter3.hasNext())
				{
					warrantyInfo.add(iter3.next());
				}
				break;
			case 4:
				Iterator iter4 = participantList.get(i).retrieveInformation();
				while(iter4.hasNext())
				{
					contractInfo.add(iter4.next());
				}
			}
			
			if(type.equals("IT Assets"))
			{
				//ITAssetController.getInstance().addITAsset(ITAsset(/*PARAMETERS*/));
			}
			else if(type.equals("Non-IT Assets"))
			{
				//ITAssetController.getInstance().addITAsset(ITAsset(/*PARAMETERS*/));
			}
			else if(type.equals("Software"))
			{
				//SoftwareController.getInstance().addITAsset(ITAsset(/*PARAMETERS*/));
			}
			else if(type.equals("General"))
			{
				InventoryItemController.getInstance().addInventoryItem(new InventoryItem(0, generalInfo.get(0).toString(), generalInfo.get(1).toString(), generalInfo.get(2), (String)generalInfo.get(3), generalInfo.get(4), generalInfo.get(5), generalInfo.get(6)));
			}
		}
	}
	
	public void setTabInventory(TabInventory tabInventory)
	{
		this.tabInventory = tabInventory;
	}
	
	public void setCurrentType(String type) {
		
			if(type.equals("IT Assets"))
			{
				tabInventory.displayIT();
			}
			else if(type.equals("Non-IT Assets"))
			{
				tabInventory.displayNonIT();
			}
			else if(type.equals("Software"))
			{
				tabInventory.displaySoftware();
			}
			else if(type.equals("General"))
			{
				tabInventory.displayGeneral();
			}
	}
	
	public static PanelRegistry getInstance()
	{
		return panelRegistry;
	}

}
